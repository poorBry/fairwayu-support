Fairway U course data
Built 2026-11-25. 135 courses, the same files the app ships.

Contains information from OpenStreetMap (https://www.openstreetmap.org/copyright),
which is made available here under the Open Database License (ODbL) 1.0,
https://opendatacommons.org/licenses/odbl/1-0/
(c) OpenStreetMap contributors.

This database is a Derivative Database of OpenStreetMap and is made available
under the same license; the full text is in LICENSE-ODbL-1.0.txt.

Elevation courtesy of the U.S. Geological Survey, 3D Elevation Program.

What was changed: golf holes, greens, fairways, tees, bunkers, water and trees
were taken from OpenStreetMap, converted to yards from each tee, smoothed and
drawn onto a 2.5-yard grid. Courses were given fictional names. Some holes were
lengthened, reordered or re-parred, trees were added or cleared, and pins,
terrain and difficulty numbers were added.

Format: one JSON file per course. "geo" places each hole on the earth (the
tee's latitude and longitude and the turn from north); "holes" holds each
hole's line, green, pin, "terrain" (heights in yards on a 15-yard grid) and
"paint" (the ground grid: cellsRLE and heightsRLE are base64 pairs of value
and run length).
